import React from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import { useRouter } from 'expo-router';
import { useAppSelector } from '@/shared/hooks/useAppSelector';
import {
  BackIcon,
  BellIcon,
  CameraIcon,
} from '@/components/UI/icons/svg-icons';

interface GreenHeaderProps {
  paddingTop: number;
  onPressCamera?: () => void;
}

export const GreenHeader: React.FC<GreenHeaderProps> = ({
  paddingTop,
  onPressCamera,
}) => {
  const router = useRouter();
  const { user } = useAppSelector((state) => state.auth);

  return (
    <View
      className="px-[38px]"
      style={{
        paddingTop: paddingTop + 20,
      }}>
      {/* Top Row */}
      <View className="flex-row justify-between items-center">
        <TouchableOpacity onPress={() => router.back()}>
          <BackIcon />
        </TouchableOpacity>
        <View className="bg-[#DFF7E2] rounded-[25.7px] w-[30px] h-[30px] items-center justify-center">
          <BellIcon />
        </View>
      </View>

      {/* Title */}
      <View className="mt-5 items-center">
        <Text className="font-poppins-semibold text-[20px] text-[#093030] capitalize">
          Edit my Profile
        </Text>
      </View>

      {/* Profile Avatar */}
      <View className="mt-2.5 items-center">
        <View className="relative w-[117px] h-[117px] mb-5">
          <View className="w-[117px] h-[117px] rounded-[58.5px] bg-[#C5F0DC] items-center justify-center">
            <Text className="font-poppins-bold text-[48px] text-[#00D09E]">
              {user?.fullName?.charAt(0).toUpperCase() || 'U'}
            </Text>
          </View>

          {/* Camera Icon */}
          <TouchableOpacity
            onPress={onPressCamera}
            className="absolute"
            style={{ bottom: 8, right: 8 }}>
            <View className="w-[25px] h-[25px] rounded-[21.4px] bg-[#00D09E] items-center justify-center">
              <CameraIcon />
            </View>
          </TouchableOpacity>
        </View>

        {/* User Name */}
        <Text className="font-poppins-bold text-[20px] text-[#0E3E3E] capitalize">
          {user?.fullName || 'User Name'}
        </Text>

        {/* User ID */}
        <Text className="font-poppins-semibold text-[13px] text-[#093030] mt-1">
          ID:{' '}
          <Text className="font-poppins-light text-[#093030]">
            {user?.id || 'N/A'}
          </Text>
        </Text>
      </View>
    </View>
  );
};
