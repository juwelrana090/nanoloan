import React from 'react';
import { View, TouchableOpacity, Text, ActivityIndicator } from 'react-native';

interface UpdateProfileButtonProps {
  onPress: () => void;
  isLoading?: boolean;
  disabled?: boolean;
}

export const UpdateProfileButton: React.FC<UpdateProfileButtonProps> = ({
  onPress,
  isLoading = false,
  disabled = false,
}) => {
  return (
    <View className="px-[38px]">
      <TouchableOpacity
        onPress={onPress}
        disabled={disabled || isLoading}
        activeOpacity={0.7}
        className="items-center rounded-[30px] py-3"
        style={{
          backgroundColor: '#00D09E',
          height: 36,
          opacity: disabled || isLoading ? 0.6 : 1,
        }}>
        {isLoading ? (
          <ActivityIndicator color="#093030" />
        ) : (
          <Text className="font-poppins-medium text-[15px] text-[#093030]">
            Update Profile
          </Text>
        )}
      </TouchableOpacity>
    </View>
  );
};
