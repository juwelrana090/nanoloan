import React from 'react';
import { View, Text, Switch } from 'react-native';

interface SettingsItemProps {
  label: string;
  value: boolean;
  onValueChange?: (value: boolean) => void;
  showToggle?: boolean;
}

export const SettingsItem: React.FC<SettingsItemProps> = ({
  label,
  value,
  onValueChange,
  showToggle = true,
}) => {
  return (
    <View className="flex-row items-center gap-[13px]">
      <Text className="font-poppins-medium text-[15px] text-[#093030] w-[130px]">
        {label}
      </Text>
      {showToggle ? (
        <View className="flex-1 flex-row justify-end">
          <Switch
            value={value}
            onValueChange={onValueChange}
            trackColor={{ false: '#DFF7E2', true: '#00D09E' }}
            thumbColor="#FFFFFF"
            ios_backgroundColor="#DFF7E2"
          />
        </View>
      ) : (
        <View className="flex-1" />
      )}
    </View>
  );
};
