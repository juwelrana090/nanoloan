import React from 'react';
import { View, Text } from 'react-native';
import { useAppSelector } from '@/shared/hooks/useAppSelector';

interface AccountSettingsSectionProps {
  onUsernameChange?: (text: string) => void;
  onPhoneChange?: (text: string) => void;
  onEmailChange?: (text: string) => void;
  editable?: boolean;
}

export const AccountSettingsSection: React.FC<AccountSettingsSectionProps> = ({
  onUsernameChange,
  onPhoneChange,
  onEmailChange,
  editable = false,
}) => {
  const { user } = useAppSelector((state) => state.auth);

  return (
    <View className="gap-[61px] mt-[30px]">
      {/* Section Title */}
      <View className="w-[177px]">
        <Text className="font-poppins-semibold text-[20px] text-[#093030]">
          account settings
        </Text>
      </View>

      {/* Username Field */}
      <View className="flex-row items-center gap-[13px]">
        <Text className="font-poppins-medium text-[15px] text-[#093030] w-[130px]">
          Username
        </Text>
        <View
          className="flex-1 flex-row items-center gap-[10px] px-5 py-[14px] rounded-[10px]"
          style={{ backgroundColor: '#DFF7E2' }}>
          <Text className="font-poppins-light text-[13px] text-[#093030] flex-1">
            {user?.username || 'N/A'}
          </Text>
        </View>
      </View>

      {/* Phone Field */}
      <View className="flex-row items-center gap-[13px]">
        <Text className="font-poppins-medium text-[15px] text-[#093030] w-[130px]">
          phone
        </Text>
        <View
          className="flex-1 flex-row items-center gap-[10px] px-5 py-[14px] rounded-[10px]"
          style={{ backgroundColor: '#DFF7E2' }}>
          <Text className="font-poppins-light text-[13px] text-[#0E3E3E] flex-1">
            {user?.phoneNumber || '+44 555 5555 55'}
          </Text>
        </View>
      </View>

      {/* Email Field */}
      <View className="flex-row items-center gap-[13px]">
        <Text className="font-poppins-medium text-[15px] text-[#093030] w-[130px]">
          email address
        </Text>
        <View
          className="flex-1 flex-row items-center gap-[10px] px-5 py-[14px] rounded-[10px]"
          style={{ backgroundColor: '#DFF7E2' }}>
          <Text className="font-poppins-light text-[13px] text-[#093030] lowercase flex-1">
            {user?.email || 'example@example.com'}
          </Text>
        </View>
      </View>
    </View>
  );
};
