import React, { useState } from 'react';
import { View, ScrollView, Alert, Switch, Text } from 'react-native';
import { useSafePadding } from '@/shared/hooks/useSafePadding';
import { useRouter } from 'expo-router';
import {
  GreenHeader,
  AccountSettingsSection,
  SettingsItem,
  UpdateProfileButton,
} from '@/modules/profile/components';

export default function EditProfileScreen() {
  const { paddingTop, scrollPaddingBottom } = useSafePadding();
  const router = useRouter();
  const [isUpdating] = useState(false);

  // Settings state
  const [darkThemeEnabled, setDarkThemeEnabled] = useState(false);
  const [pushNotificationsEnabled, setPushNotificationsEnabled] = useState(true);

  const handleUpdateProfile = () => {
    Alert.alert(
      'Update Profile',
      'This feature will be implemented with the full profile update API integration.',
      [
        {
          text: 'OK',
          onPress: () => router.back(),
        },
      ]
    );
  };

  const handleCameraPress = () => {
    Alert.alert(
      'Update Profile Picture',
      'Camera/gallery functionality will be implemented for profile picture updates.',
      [{ text: 'OK' }]
    );
  };

  return (
    <View className="flex-1 bg-[#00D09E]">
      {/* Green Header */}
      <GreenHeader paddingTop={paddingTop} onPressCamera={handleCameraPress} />

      {/* White Content Area */}
      <View
        className="bg-[#F1FFF3] px-[38px]"
        style={{
          paddingBottom: scrollPaddingBottom + 100,
        }}>
        <ScrollView
          className="flex-1"
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingBottom: 20 }}>
          {/* Account Settings Section */}
          <AccountSettingsSection />

          {/* Turn Dark Theme Toggle */}
          <View className="mt-[50px]">
            <SettingsItem
              label="Turn dark Theme"
              value={darkThemeEnabled}
              onValueChange={setDarkThemeEnabled}
            />
          </View>

          {/* Push Notifications Toggle */}
          <View className="mt-[40px]">
            <View className="flex-row items-center gap-[13px]">
              <Text className="font-poppins-medium text-[15px] text-[#093030] w-[150px]">
                push notifications
              </Text>
              <View className="flex-1 flex-row justify-end">
                <Switch
                  value={pushNotificationsEnabled}
                  onValueChange={setPushNotificationsEnabled}
                  trackColor={{ false: '#DFF7E2', true: '#00D09E' }}
                  thumbColor="#FFFFFF"
                  ios_backgroundColor="#DFF7E2"
                />
              </View>
            </View>
          </View>

          {/* Update Profile Button */}
          <View className="mt-[60px]">
            <UpdateProfileButton
              onPress={handleUpdateProfile}
              isLoading={isUpdating}
            />
          </View>
        </ScrollView>
      </View>
    </View>
  );
}
